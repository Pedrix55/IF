let alunos = ['Ester', 'Pedro', 'Yasmin', 'Adrielle'];

for (let i = 0; i < 4; i++) {
    console.log("Estudantes: " + alunos[i])
}

console.log("Feliz dia do estudante!")