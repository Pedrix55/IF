/*let nomes = ["Ester", "Elias", "Emilly"]

for (let elemento of nomes) {
    console.log(elemento)
}

for (let i = 0; i < nomes; i++) {
    console.log(nomes[i]);
}*/

//-------------------------------------------------------------------------------------------------------------------

let nomes = ["Ester", "Elias", "Emilly"]
let artista = ["Coldplay", "Alok", "Rosalina"]

for (let i = 0; i < nomes.length; i++) {
    for (let j = 0; j < artista.length; j++) {
        console.log(nomes[i] + "" + artista[j]);
    }
}