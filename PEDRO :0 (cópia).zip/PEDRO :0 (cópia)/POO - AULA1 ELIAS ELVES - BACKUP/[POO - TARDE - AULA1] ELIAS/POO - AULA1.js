/*let idade = prompt("Digite sua idade");

if (idade >= 18){

    console.log("você é MAIOR de idade!");
 } else {

     console.log("você é Menor de idade!");
}
     */


// AULA 2 - POO | ELIAS.

