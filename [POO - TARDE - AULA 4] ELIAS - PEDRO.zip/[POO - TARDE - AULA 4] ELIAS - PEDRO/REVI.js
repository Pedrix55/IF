let nomes = [];
let idades = [];
let matriculas = [];

let matriculaBusca;

for (let i = 0; i < matriculas.length; i++) {
    if (buscarMatricula === matricula[i]) {
        console.log('Y: X, sua idade é Z')

    }


}