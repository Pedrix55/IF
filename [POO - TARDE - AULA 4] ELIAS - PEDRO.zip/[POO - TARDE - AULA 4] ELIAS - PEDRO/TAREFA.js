let produto1 = {
    nome: '',
    valor: 0
}


let produto2 = {
    nome: '',
    valor: 0
}

produto1.nome = prompt('Nome do produto 1: ')
produto1.valor = prompt('Valor do produto 1: ')
produto2.nome = prompt('Nome do produto 2: ')
produto2.valor = prompt('Valor do produto: ')

if (produto1.valor === produto2.valor) {
    console.log('O produto ' + produto1.nome + ' e o produto ' + produto2.nome + ' tem o mesmo valor: R$' + produto2.valor);
} else {

    console.log('O produto ' + produto1.nome + ' e o produto ' + produto2.nome + ' tem valores diferentes R$ ' + produto1.valor + ' e R$ ' + produto2.valor);

}