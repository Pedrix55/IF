

let carro1 = { modelo: 'Ford Ranger', cor: 'Branco', anoF: 2018, valor: 157.800 }
let carro2 = { modelo: 'HONDA HR-V', cor: 'Branco', anoF: 2018, valor: 97.999 }
let carro3 = { modelo: 'FIAT TORO', cor: 'Vermelho', anoF: 2020, valor: 121.999 }
let carro4 = { modelo: 'VOLKSWAGEN NIVUS', cor: 'Vermelho', anoF: 2021, valor: 128.800 }

console.log(carro1)
console.log(carro2)
console.log(carro3)
console.log(carro4)