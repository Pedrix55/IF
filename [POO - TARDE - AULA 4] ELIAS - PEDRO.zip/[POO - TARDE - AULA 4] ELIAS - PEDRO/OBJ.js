let aluno1 = {
    nome: 'Jão',        //Atibuto ou propriedade
    idade: 21,          //Atibuto ou propriedade
    matricula: 'if1'    //Atibuto ou propriedade
};

let aluno2 = {
    nome: 'Zé',           //Atibuto ou propriedade
    idade: 22,           //Atibuto ou propriedade
    matricula: 'if2'    //Atibuto ou propriedade
};

console.log(aluno2.idade); // imprimir a idade do aluno2 
console.log(aluno1.nome); // imprimir o nome do aluno1                          